package com.deepgenx.CodeGenX;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeGenXApplicationTests {

	@Test
	void contextLoads() {
	}

}
